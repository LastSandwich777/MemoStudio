package com.example.testapp;

public class Bean {
    private int _ID;
    private String contents;
    private String score;
    private int right_answer;
    private int mode_text_image;
    private String SHOW_1;
    private String SHOW_2;
    private String SHOW_3;
    private String SHOW_4;
    private byte[] Image_SHOW_1;
    private byte[] Image_SHOW_2;
    private byte[] Image_SHOW_3;
    private byte[] Image_SHOW_4;

    public byte[] getImage_SHOW_1() {
        return Image_SHOW_1;
    }

    public void setImage_SHOW_1(byte[] image_SHOW_1) {
        Image_SHOW_1 = image_SHOW_1;
    }

    public byte[] getImage_SHOW_2() {
        return Image_SHOW_2;
    }

    public void setImage_SHOW_2(byte[] image_SHOW_2) {
        Image_SHOW_2 = image_SHOW_2;
    }

    public byte[] getImage_SHOW_3() {
        return Image_SHOW_3;
    }

    public void setImage_SHOW_3(byte[] image_SHOW_3) {
        Image_SHOW_3 = image_SHOW_3;
    }

    public byte[] getImage_SHOW_4() {
        return Image_SHOW_4;
    }

    public void setImage_SHOW_4(byte[] image_SHOW_4) {
        Image_SHOW_4 = image_SHOW_4;
    }

    public int get_ID() {
        return _ID;
    }

    public void set_ID(int _ID) {
        this._ID = _ID;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public int getRight_answer() {
        return right_answer;
    }

    public void setRight_answer(int right_answer) {
        this.right_answer = right_answer;
    }

    public int getMode_text_image() {
        return mode_text_image;
    }

    public void setMode_text_image(int mode_text_image) {
        this.mode_text_image = mode_text_image;
    }

    public String getSHOW_1() {
        return SHOW_1;
    }

    public void setSHOW_1(String SHOW_1) {
        this.SHOW_1 = SHOW_1;
    }

    public String getSHOW_2() {
        return SHOW_2;
    }

    public void setSHOW_2(String SHOW_2) {
        this.SHOW_2 = SHOW_2;
    }

    public String getSHOW_3() {
        return SHOW_3;
    }

    public void setSHOW_3(String SHOW_3) {
        this.SHOW_3 = SHOW_3;
    }

    public String getSHOW_4() {
        return SHOW_4;
    }

    public void setSHOW_4(String SHOW_4) {
        this.SHOW_4 = SHOW_4;
    }
}
